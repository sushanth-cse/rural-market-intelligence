// FarmGain Main Single-Page Application (SPA) Central State & Router

class FarmGainApp {
  constructor() {
    this.state = {
      role: 'farmer',           // 'farmer' | 'buyer'
      lang: 'en',               // 'en' | 'kn' | 'hi'
      activeTab: 'home',        // 'home' | 'markets' | 'comparison' | 'forecast' | 'calc' | 'chat'
      selectedCrop: 'tomato',
      selectedQuantity: 500,
      selectedLocation: 'kolar',
      selectedVehicle: 'mini_truck',
      selectedCalcBuyer: 'b1',
      activeChatBuyerId: 'b1',
      unreadChat: false,
      sellingModalBuyerId: null,
      formulaModalBuyerId: null,
      chatHistory: mockInitialChats
    };

    window.appState = this;
  }

  init() {
    this.render();
  }

  setState(newState) {
    this.state = { ...this.state, ...newState };
    this.render();
  }

  setRole(role) {
    this.setState({ role });
  }

  setLang(lang) {
    this.setState({ lang });
  }

  setActiveTab(tab) {
    this.setState({ activeTab: tab });
  }

  setSelectedCrop(cropId) {
    this.setState({ selectedCrop: cropId });
  }

  setSelectedQuantity(qty) {
    this.setState({ selectedQuantity: qty });
  }

  setSelectedLocation(locId) {
    this.setState({ selectedLocation: locId });
  }

  setSelectedVehicle(vId) {
    this.setState({ selectedVehicle: vId });
  }

  setSelectedCalcBuyer(buyerId) {
    this.setState({ selectedCalcBuyer: buyerId });
  }

  useCurrentGPSLocation() {
    this.setSelectedLocation('custom');
    alert("📍 GPS Location set to: Kolar Rural Hub (13.1367° N, 78.1292° E)");
  }

  triggerSearch() {
    this.setActiveTab('markets');
  }

  selectCropAndNavigate(cropId, targetTab) {
    this.setState({ selectedCrop: cropId, activeTab: targetTab });
  }

  openChat(buyerId) {
    this.setState({ activeChatBuyerId: buyerId, activeTab: 'chat' });
  }

  sendChatMessage(buyerId, text) {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const current = this.state.chatHistory[buyerId] || [];
    const updated = [...current, { sender: 'farmer', time, text }];
    
    // Simulated auto reply from buyer after 1 second
    setTimeout(() => {
      const reply = { sender: 'buyer', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), text: "Offer received! We can accept your batch today. Please bring your vehicle to Gate 2." };
      this.state.chatHistory[buyerId] = [...(this.state.chatHistory[buyerId] || []), reply];
      if (this.state.activeTab === 'chat' && this.state.activeChatBuyerId === buyerId) {
        this.render();
      }
    }, 1200);

    this.setState({
      chatHistory: {
        ...this.state.chatHistory,
        [buyerId]: updated
      }
    });
  }

  sendChatMessageFromInput(buyerId) {
    const input = document.getElementById('chatInputText');
    if (!input || !input.value.trim()) return;
    this.sendChatMessage(buyerId, input.value.trim());
    input.value = '';
  }

  openSellingModal(buyerId) {
    this.setState({ sellingModalBuyerId: buyerId });
  }

  closeSellingModal() {
    this.setState({ sellingModalBuyerId: null });
  }

  submitSellingRequestFromModal() {
    const nameEl = document.getElementById('reqFarmerName');
    const phoneEl = document.getElementById('reqFarmerPhone');
    const addrEl = document.getElementById('reqFarmerAddress');

    const buyer = mockBuyers.find(b => b.id === this.state.sellingModalBuyerId) || mockBuyers[0];
    const cropObj = mockCrops.find(c => c.id === this.state.selectedCrop) || mockCrops[0];

    const requestPayload = {
      farmerName: nameEl ? nameEl.value : 'Ramesh Kumar',
      farmerPhone: phoneEl ? phoneEl.value : '+91 94801 22334',
      buyerId: buyer.id,
      buyerName: buyer.name,
      crop: cropObj.name,
      cropId: cropObj.id,
      quantityKg: this.state.selectedQuantity,
      offeredPricePerKg: buyer.pricePerKg,
      grossValue: this.state.selectedQuantity * buyer.pricePerKg,
      location: addrEl ? addrEl.value : 'Kolar Rural',
      status: 'Pending',
      timestamp: 'Just now'
    };

    mockSellingRequests.unshift(requestPayload);
    this.closeSellingModal();

    alert(`✅ Selling request of ${this.state.selectedQuantity} kg ${cropObj.name} sent successfully to ${buyer.name}!`);
    this.openChat(buyer.id);
  }

  openFormulaModal(buyerId) {
    this.setState({ formulaModalBuyerId: buyerId });
  }

  closeFormulaModal() {
    this.setState({ formulaModalBuyerId: null });
  }

  updateRequestStatus(reqId, status) {
    const req = mockSellingRequests.find(r => r.id === reqId);
    if (req) {
      req.status = status;
      this.render();
    }
  }

  render() {
    renderHeader('headerContainer', this.state);
    renderMobileNav('mobileNavContainer', this.state);

    const mainContainer = document.getElementById('mainContent');
    if (!mainContainer) return;

    // Check Role
    if (this.state.role === 'buyer') {
      renderBuyerDashboard('mainContent', this.state);
    } else {
      // Farmer Tabs
      switch (this.state.activeTab) {
        case 'home':
          renderFarmerDashboard('mainContent', this.state);
          break;
        case 'markets':
          renderCropSearch('mainContent', this.state);
          break;
        case 'comparison':
          renderMarketComparison('mainContent', this.state);
          break;
        case 'forecast':
          renderPriceForecast('mainContent', this.state);
          break;
        case 'calc':
          renderTransportCalc('mainContent', this.state);
          break;
        case 'chat':
          renderChatWindow('mainContent', this.state);
          break;
        default:
          renderFarmerDashboard('mainContent', this.state);
      }
    }

    // Render Modals
    renderSellingModal('modalContainer', this.state);
    renderFormulaModal('formulaModalContainer', this.state);
  }
}

// Global initialization
document.addEventListener('DOMContentLoaded', () => {
  const app = new FarmGainApp();
  app.init();
});
